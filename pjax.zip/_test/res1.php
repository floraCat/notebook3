<?php 
echo "<div style='background:red;'>第一页</div>";
?>