<?php 
echo "<div style='background:red;'>第二页</div>";
?>