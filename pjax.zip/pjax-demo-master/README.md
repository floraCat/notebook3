# pjax-demo

运行如下命令初始化项目

```shell
bower install
npm install
```

运行项目

```shell
DEBUG=pjax ./bin/www
```

访问 `http://localhost:3000`